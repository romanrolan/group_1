import React from 'react';
import './AllNews.css';

const AllNews = (props) =>
  <div className='AllNews'>
    <h3 className='title'>All news</h3>
    <ul>
      <li>First News</li>
      <li>Second News</li>
      <li>Third News</li>
    </ul>
  </div>

export default AllNews;
